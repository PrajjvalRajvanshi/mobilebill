package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.PostpaidAccount;

public class BillDAOImpl implements BillDAO{
	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Bill save(Bill bill) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(bill);
		entityManager.getTransaction().commit();
		entityManager.close();
		return bill;
	}

	@Override
	public boolean update(Bill bill) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(bill);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Bill findOne(long billId) {
		return  entityManagerFactory.createEntityManager().find(Bill.class,billId);
	}

	@Override
	public List<Bill> findAll() {
		return  entityManagerFactory.createEntityManager().createQuery("from Bill b").getResultList();
	}

	@Override
	public Bill retrieveBill(long mobileNo, String billMonth) {
		return    (Bill) entityManagerFactory.createEntityManager().createQuery("from Bill b where b.postpaidAccount="+mobileNo+" and b.billMonth='"+billMonth+"'").getSingleResult();
	}

	@Override
	public List<Bill> retrieveAllBills(long mobileNo) {
		return  entityManagerFactory.createEntityManager().createQuery("from Bill b where b.postpaidAccount="+mobileNo).getResultList();
	}

	
}
