package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Bill;
public interface BillDAO
{
	Bill save(Bill bill);
    boolean update(Bill bill);
    Bill findOne(long billId);
    List<Bill> findAll();
    Bill retrieveBill(long mobileNo,String billMonth);
	List<Bill> retrieveAllBills(long mobileNo);
}
